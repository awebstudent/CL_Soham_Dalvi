
import express, {Request , Response} from 'express';
import { spliting, concat, isLeapYear, handshake} from './logic';

const app = express();
const port = 8000; //
 //I used const since the values wont be changed once assigned

 //a
app.get('/split/:inputString', (req: Request, res: Response) => {
    const input: string = req.params.inputString;
    const output1: string = spliting(input);
    res.json({ output1 });
  });


//b
  app.get('/concat/:param1/:param2', (req: Request, res: Response) => {
    const param1: string = req.params.param1;
    const param2: string = req.params.param2;
    const finalOutput: string = concat(param1, param2);
    res.json( finalOutput );
  });


//c

app.get('/isLeapYear/:year', (req: Request, res: Response) => {
    const year: number = parseInt(req.params.year);
    if (isNaN(year)) {
      res.send("Please enter a valid year!")
    } else {
      const isLeap: boolean = isLeapYear(year);
      if(isLeap){
        res.send("The year " + year + " is Leap!" );   //tried different method other than res.json
      }else{
        res.send("The year " + year + " is not Leap!" );
      }
      
    }
  });

  app.get('/handshake/:num', (req: Request, res: Response) => {
   
    const num: number = parseInt(req.params.num);

    
    if (isNaN(num) || num < 1 || num > 31) {
        res.send('Invalid input. Please give a number between 1 and 31.');
    } else {
        const handshakeOutput = handshake(num);
        res.json({ handshakeOutput });
    }
});


app.listen(port, ()=> {
 console.log(`Server runnning on port ${port} `);
})