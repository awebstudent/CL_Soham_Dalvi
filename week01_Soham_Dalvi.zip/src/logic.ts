

export function spliting(inputString: string): string {
    return inputString.replace('_', ' ');
  }
  
  export function concat(param1: string, param2: string): string {
    return param1 + param2;
  }
  
export function isLeapYear(year: number): boolean {
    if ((year % 400 === 0)||year % 4 === 0 && year % 100 !== 0) {
      return true;
    }
    return false;
  }

 //solved on excercism and all test cases passed.
  export function handshake(num : number) : string[] {
    const binary : string = num.toString(2);
    const size = binary.length;

    let arr : string[] = [];

        for (let i = size - 1; i >= 0; i--) {
        if (binary[i] === '1') {
            
            switch (size - 1 - i) {
                case 4:
                    arr.reverse();
                    break;
                case 3:
                    arr.push('jump');
                    break;
                case 2:
                    arr.push('close your eyes');
                    break;
                case 1:
                    arr.push('double blink');
                    break;
                case 0:
                    arr.push('wink');
                    break;
            }
        }
    }
    return arr;

}
